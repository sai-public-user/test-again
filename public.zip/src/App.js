import React from 'react';
import './App.css';
import 'semantic-ui-css/semantic.min.css';

// import Catalog from './Catalog/catalog';
import TableData from './TableData/tableData';

function App() {
  return (
    <div className="App">
      <TableData />
      {/* <Catalog /> */}
    </div>
  );
}

export default App;
