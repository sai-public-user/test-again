import React, { Component, Fragment } from 'react';
import {
    Input,
    Grid,
    Radio,
    GridColumn,
    GridRow,
    Dropdown,
    Checkbox,
} from 'semantic-ui-react';

import TableHeader from './tableHeader';
import TableRows from './tableRows';

class TableData extends Component {
    constructor(props) {
        super(props);
        this.state = {
            headers: [
                { name: 'Ticket Id', value: 'id' },
                { name: 'Task Name', value: 'name' },
                { name: 'Status', value: 'status' },
                { name: 'Requestor RACFID', value: 'rafcid' },
                { name: 'Migration Status', value: 'mstatus'},
                { name: 'Actions', value: 'actions' },
            ],
            rows: [
                {
                    id: 'DPR12149',
                    name: 'Backend URL Change',
                    status: 'Completed',
                    rafcid: 'I3eb',
                    mstatus: 'N/A',
                }, {
                    id: 'DPR12150',
                    name: 'Backend URL Not Change',
                    status: 'Completing',
                    rafcid: 'I3fc',
                    mstatus: 'N/A',
                },
                
            ],
            expandedrows: [],
            radiosChecked: [],
        };
    }

    onExpandRow = (e) => {
        const { currentTarget } = e
        const name = currentTarget.getAttribute('name');
        let { expandedrows = [] } = this.state;
        if (expandedrows.includes(name)) expandedrows = expandedrows.filter(one => one !== name);
        else expandedrows.push(name); 
        this.setState({ expandedrows });
    }

    onRadioClick = (e, { name }) => {
        let { radiosChecked = [] } = this.state;
        if (radiosChecked.includes(name)) radiosChecked = radiosChecked.filter(one => one !== name);
        else radiosChecked.push(name); 
        this.setState({ radiosChecked });
    }

    render() {
        const { headers, rows, expandedrows, radiosChecked } = this.state;
        const options = [
            { key: "angular", text: <Checkbox label="Angular" />, value: "angular" },
            { key: "react", text: <Checkbox label="React" />, value: "react" },
            { key: "node", text: <Checkbox label="Node" />, value: "node" },
            { key: "electron", text: <Checkbox label="Electron" />, value: "electron" }
          ];
        return ( 
            <Grid>
                <GridRow>
                    <Grid className="tableSearch" middle columns={3}>
                        <GridColumn><Input className="search-field" icon='search' placeholder='Search...' /></GridColumn>
                        <GridColumn middle centered className="filters" style={{ marginTop: 5 }}>
                            <span className="filtertag">Filter by:</span>
                            <Radio label='Completed' checked={radiosChecked.includes('completed')} name="completed" onClick={this.onRadioClick} />
                            <Radio label='In Progress' checked={radiosChecked.includes('inprogress')} name="inprogress" onClick={this.onRadioClick} />
                            <Radio label='Denied' checked={radiosChecked.includes('denied')} name="denied" onClick={this.onRadioClick} />
                            <Radio label='Drafted' checked={radiosChecked.includes('drafted')} name="drafted" onClick={this.onRadioClick} />
                        </GridColumn>
                        <GridColumn>
                            <Grid columns={2}>
                                <GridColumn><Dropdown placeholder="Skills" fluid multiple selection options={options} /></GridColumn>
                                <GridColumn><Dropdown placeholder="Skills" fluid multiple selection options={options} /></GridColumn>
                            </Grid>
                        </GridColumn>
                    </Grid>
                </GridRow>
                <GridRow style={{ paddingTop: 0 }}>
                    <GridColumn class="tableData">
                        <TableHeader headers={headers} />
                        <TableRows headers={headers} rows={rows} expandedrows={expandedrows} expandRow={this.onExpandRow} />
                    </GridColumn>
                </GridRow>
            </Grid>
         );
    }
}
 
export default TableData;
